function AS_Label_214db444b3a94f128f3bde698113d540(eventobject, x, y) {
    return onClickMyORder.call(this, eventobject);
}