function AS_Image_98855bbbde1f4202b2adfa4b06f6ec86(eventobject, x, y) {
    return nav_onclick_imghelpbtn.call(this);
}