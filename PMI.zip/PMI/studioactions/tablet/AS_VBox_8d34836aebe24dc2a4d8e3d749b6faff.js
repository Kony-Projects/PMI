function AS_VBox_8d34836aebe24dc2a4d8e3d749b6faff(eventobject) {
    return tfasites_NextPrev.call(this, "Prev");
}