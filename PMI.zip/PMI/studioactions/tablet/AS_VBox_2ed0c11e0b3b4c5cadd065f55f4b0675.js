function AS_VBox_2ed0c11e0b3b4c5cadd065f55f4b0675(eventobject) {
    popAtachment.dismiss();
    popCreateTicket.dismiss();
    popErrorMsg.dismiss();
    popNotification.dismiss();
}