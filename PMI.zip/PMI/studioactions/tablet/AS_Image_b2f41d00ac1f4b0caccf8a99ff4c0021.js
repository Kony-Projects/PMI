function AS_Image_b2f41d00ac1f4b0caccf8a99ff4c0021(eventobject, x, y) {
    hbxHeaderPop.lblHeaderName.text = "Delete";
    popDelete.show();
    delflag = true;
}