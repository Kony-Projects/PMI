function AS_Button_05704cb132484f4289a5248d8c6d7576(eventobject) {
    return tfasites_NextPrev.call(this, "Prev");
}