function AS_Image_25f9ae950ac848ab89ce5b092de6d35c(eventobject, x, y) {
    return nofityPriorty_BtnClick.call(this);
}