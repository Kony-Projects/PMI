function AS_Image_bf89db092666479f98c2030d1c4118be(eventobject, x, y) {
    return IbuttonClick_i44.call(this);
}