function AS_Label_81169ad0c09d4d83b4da669437b96438(eventobject, x, y) {
    frmChangePassword.show();
}