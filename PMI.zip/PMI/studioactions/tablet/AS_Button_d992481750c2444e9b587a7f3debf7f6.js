function AS_Button_d992481750c2444e9b587a7f3debf7f6(eventobject, context) {
    return Attachment_Btnonclick.call(this);
}