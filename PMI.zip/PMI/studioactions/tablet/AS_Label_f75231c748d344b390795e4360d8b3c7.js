function AS_Label_f75231c748d344b390795e4360d8b3c7(eventobject, x, y) {
    return call_empty_func.call(this);
}