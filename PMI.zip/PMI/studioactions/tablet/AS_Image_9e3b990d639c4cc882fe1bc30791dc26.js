function AS_Image_9e3b990d639c4cc882fe1bc30791dc26(eventobject, x, y) {
    return ClickOnImgOrderList.call(this);
}