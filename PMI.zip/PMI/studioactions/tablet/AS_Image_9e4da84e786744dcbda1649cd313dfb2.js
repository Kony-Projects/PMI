function AS_Image_9e4da84e786744dcbda1649cd313dfb2(eventobject, x, y) {
    hbxHeaderPop.lblHeaderName.text = "Long Text";
    popLongText.show()
}