function AS_Button_059d51de74754319ab30b38973ba8c89(eventobject) {
    return myOrderfetch.call(this, eventobject);
}