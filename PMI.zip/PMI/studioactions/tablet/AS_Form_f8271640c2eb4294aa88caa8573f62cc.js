function AS_Form_f8271640c2eb4294aa88caa8573f62cc(eventobject) {
    frmChangePassword.destroy();
}