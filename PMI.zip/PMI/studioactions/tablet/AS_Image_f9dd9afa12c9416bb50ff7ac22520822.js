function AS_Image_f9dd9afa12c9416bb50ff7ac22520822(eventobject, x, y) {
    return ibuttonClick_ZQE.call(this);
}