function AS_VBox_a8447473319645bbb8c976ff2a62804a(eventobject) {
    return nav_onback_btn_press.call(this);
}