function AS_Segment_46e0d397b2324cceb5c8f472d30e2c22(eventobject, sectionNumber, rowNumber) {
    return OnSelectNotfytxt.call(this);
}