function AS_Image_b756e62261974134b96c64c5028fad5e(eventobject, x, y) {
    return ClickOnImgofSubOrderListZI44.call(this);
}