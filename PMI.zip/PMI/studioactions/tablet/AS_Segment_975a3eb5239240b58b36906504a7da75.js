function AS_Segment_975a3eb5239240b58b36906504a7da75(eventobject, sectionNumber, rowNumber) {
    return rowSegCLick.call(this, null);
}