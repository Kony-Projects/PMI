function AS_VBox_8fb209af9bcc4483b8afacd9397d9f55(eventobject) {
    return tfasites_NextPrev.call(this, "Next");
}