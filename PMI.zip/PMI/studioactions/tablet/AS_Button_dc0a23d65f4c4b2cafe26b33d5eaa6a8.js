function AS_Button_dc0a23d65f4c4b2cafe26b33d5eaa6a8(eventobject) {
    return changepassword.call(this);
}