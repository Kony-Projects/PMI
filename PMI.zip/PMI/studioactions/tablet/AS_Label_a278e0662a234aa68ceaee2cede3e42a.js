function AS_Label_a278e0662a234aa68ceaee2cede3e42a(eventobject, x, y) {
    return set_popval.call(this, "PlantSection", popPrevNext, frmLandingScreen.lblPsValue);
}