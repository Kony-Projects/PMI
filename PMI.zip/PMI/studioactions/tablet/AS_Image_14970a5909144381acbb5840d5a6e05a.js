function AS_Image_14970a5909144381acbb5840d5a6e05a(eventobject, x, y) {
    hbxHeaderPop.lblHeaderName.text = "Create Ticket";
    popCreateTicket.show()
}