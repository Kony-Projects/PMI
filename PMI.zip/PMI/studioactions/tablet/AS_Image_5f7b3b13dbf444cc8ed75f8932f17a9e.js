function AS_Image_5f7b3b13dbf444cc8ed75f8932f17a9e(eventobject, x, y) {
    return SyncBtn_OnclickZWI44.call(this);
}