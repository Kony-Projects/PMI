function AS_Image_60969c4874374df99f4d36f70ad82339(eventobject, x, y) {
    return ClickOnImgofSubOrderList.call(this);
}