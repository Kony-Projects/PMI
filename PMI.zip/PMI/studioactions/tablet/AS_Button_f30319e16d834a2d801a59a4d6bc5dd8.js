function AS_Button_f30319e16d834a2d801a59a4d6bc5dd8(eventobject) {
    frmHelpScreen.show();
}