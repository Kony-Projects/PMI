function AS_Popup_3f98839ad6ea45b793bc426ce668d9ca(eventobject) {
    hbxHeaderPop.lblHeaderName.text = "Attachment";
}