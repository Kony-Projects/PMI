function AS_Form_bb423c2b767a49de94bd9996c4883a1b(eventobject) {
    hbxHeaderPop.lblHeaderName.text = "Exit";
    popBack.lblBack.text = "Do You Want to Exit ?";
    popBack.show()
}