function AS_Segment_0230b655ebf84686940a9f27bfdea866(eventobject, sectionNumber, rowNumber) {
    return onSelectpopTxt.call(this);
}