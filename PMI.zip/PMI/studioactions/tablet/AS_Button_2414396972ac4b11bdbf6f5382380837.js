function AS_Button_2414396972ac4b11bdbf6f5382380837(eventobject, context) {
    return Attachment_Btnonclick.call(this);
}