function AS_Image_26cb6d4a0589489abc4dc9e0b0ceae1d(eventobject, x, y) {
    hbxHeaderPop.lblHeaderName.text = "Delete";
    popDelete.show();
    delflag = true;
}