function AS_Button_3db9ea36d33843999babed6c48ab1999(eventobject) {
    return popCancel.call(this, "logout");
}