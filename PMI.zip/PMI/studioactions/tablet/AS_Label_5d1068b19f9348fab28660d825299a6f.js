function AS_Label_5d1068b19f9348fab28660d825299a6f(eventobject, x, y) {
    return call_empty_func.call(this);
}