function AS_Calendar_4d175e1742034a199dbda547bfe9038d(eventobject, isValidDateSelected) {
    return six_day_check.call(this);
}