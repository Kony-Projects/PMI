function AS_Button_10600f6665344015817e5069ab5e534b(eventobject) {
    return getFetchOrder1.call(this);
}