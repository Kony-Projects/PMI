function AS_TextField_84de508b684f410f80b6db89f1ee189f(eventobject, changedtext) {
    return specialCharacter_ChangePassword.call(this);
}