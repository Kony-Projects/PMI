function AS_Image_bcd0c8365d1645309b018fc2f7d52958(eventobject, x, y) {
    return back_NavigateOrder.call(this);
}