function AS_Label_240b0b0cf374423582635dc78da685f8(eventobject, x, y) {
    return set_popval.call(this, "PMOrderType", popPrevNext, frmLandingScreen.lblPmOrderVal);
}