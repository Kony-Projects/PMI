function AS_Popup_84e69f608aaf4cdc9c743a990d76a542(eventobject) {
    popGetOrder.dismiss();
}