function AS_Button_e34cd69df3384ddc8a3c382006861537(eventobject) {
    frmLandingScreen.show();
}