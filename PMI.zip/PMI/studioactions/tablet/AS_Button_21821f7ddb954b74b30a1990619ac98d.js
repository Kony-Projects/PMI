function AS_Button_21821f7ddb954b74b30a1990619ac98d(eventobject) {
    return LongText_Submit.call(this);
}