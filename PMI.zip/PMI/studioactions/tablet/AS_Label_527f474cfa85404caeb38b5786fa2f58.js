function AS_Label_527f474cfa85404caeb38b5786fa2f58(eventobject, x, y) {
    frmChangePassword.show();
}