function AS_Image_0f5c1551d1ac4b59b065211ef7f88b29(eventobject, x, y) {
    hbxHeaderPop.lblHeaderName.text = "Delete";
    hbxlogout1.lbllogout.text = "Do You Want to Delete";
    popLogout.show()
}