function AS_Form_adc0aec9e18746d09d743f37df7495ac(eventobject) {
    return onDeviceBack.call(this);
}