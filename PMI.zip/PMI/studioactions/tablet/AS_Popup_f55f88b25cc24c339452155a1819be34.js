function AS_Popup_f55f88b25cc24c339452155a1819be34(eventobject) {
    popCreateTicket.destroy();
}