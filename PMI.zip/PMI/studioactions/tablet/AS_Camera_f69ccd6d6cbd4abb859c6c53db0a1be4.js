function AS_Camera_f69ccd6d6cbd4abb859c6c53db0a1be4(eventobject) {
    return onCapture.call(this);
}