function AS_Image_60f8918544104131acfa4fbfad9c6747(eventobject, x, y) {
    return ClickOnImgOrderList.call(this);
}