function AS_TextField_5681d3a092e440a8afbdd9a7980ee75c(eventobject, changedtext) {
    return RangeCheck.call(this);
}