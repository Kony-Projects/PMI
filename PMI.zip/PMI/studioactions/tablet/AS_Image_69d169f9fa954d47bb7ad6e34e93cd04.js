function AS_Image_69d169f9fa954d47bb7ad6e34e93cd04(eventobject, x, y) {
    return nav_onhome_img_click.call(this);
}