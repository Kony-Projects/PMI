function AS_Button_2b8d73aa8d5f44c9af5f378fee3c6960(eventobject, context) {
    return long_BtnClick.call(this);
}