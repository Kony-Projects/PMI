function AS_Image_a8b8cc4f397c4bb1a7ff58a82bb45512(eventobject, x, y) {
    return ClickOnImgOrderList_ziw44.call(this);
}