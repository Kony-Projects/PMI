function AS_Image_5beba993287e48198e9347502b9b14b8(eventobject, x, y) {
    return set_popval.call(this, "PMOrderType", popPrevNext, frmLandingScreen.lblPmOrderVal);
}