function AS_VBox_176350f51aa34714a408897f89d61d80(eventobject) {
    return nav_onhome_img_click.call(this);
}