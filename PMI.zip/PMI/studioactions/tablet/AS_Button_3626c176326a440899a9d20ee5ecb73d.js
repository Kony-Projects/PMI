function AS_Button_3626c176326a440899a9d20ee5ecb73d(eventobject) {
    hbxHeaderPop.lblHeaderName.text = "Logout";
    popLogout.show()
}