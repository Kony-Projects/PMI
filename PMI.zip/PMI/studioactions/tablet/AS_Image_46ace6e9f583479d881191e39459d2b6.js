function AS_Image_46ace6e9f583479d881191e39459d2b6(eventobject, x, y) {
    return set_popval.call(this, "PlannerGroup", popPrevNext, frmLandingScreen.lblPgValue);
}