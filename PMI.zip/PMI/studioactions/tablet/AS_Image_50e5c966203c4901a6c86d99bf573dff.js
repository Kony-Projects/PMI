function AS_Image_50e5c966203c4901a6c86d99bf573dff(eventobject, x, y) {
    return set_popval.call(this, "PmaType", popPrevNext, frmLandingScreen.lblPmTypeVal);
}