function AS_TextField_5e4becf6a81443619d2ef317f87d4545(eventobject, changedtext) {
    return specialCharacter.call(this);
}