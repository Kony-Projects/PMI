function AS_HBox_872a8eaebf324cd09aebb36ab17a3bce(eventobject) {
    return openMediaGallery.call(this);
}