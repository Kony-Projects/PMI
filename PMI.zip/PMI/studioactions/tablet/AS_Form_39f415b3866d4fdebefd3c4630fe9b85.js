function AS_Form_39f415b3866d4fdebefd3c4630fe9b85(eventobject) {
    return onDeviceBack.call(this);
}