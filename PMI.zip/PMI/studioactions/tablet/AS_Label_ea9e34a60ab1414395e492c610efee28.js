function AS_Label_ea9e34a60ab1414395e492c610efee28(eventobject, x, y) {
    return set_popval.call(this, "Inspection Route", popPrevNext, frmLandingScreen.lblInsValue);
}