function AS_Button_4c5e992fbf7f424f928023c3b2e12b58(eventobject) {
    return SubmitDismiss.call(this);
}