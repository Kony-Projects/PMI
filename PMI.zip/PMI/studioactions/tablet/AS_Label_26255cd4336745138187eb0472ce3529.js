function AS_Label_26255cd4336745138187eb0472ce3529(eventobject, x, y) {
    return call_empty_func.call(this);
}