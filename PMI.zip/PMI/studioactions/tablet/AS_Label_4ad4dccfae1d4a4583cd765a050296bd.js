function AS_Label_4ad4dccfae1d4a4583cd765a050296bd(eventobject, x, y) {
    return onClickMyORder.call(this, eventobject);
}