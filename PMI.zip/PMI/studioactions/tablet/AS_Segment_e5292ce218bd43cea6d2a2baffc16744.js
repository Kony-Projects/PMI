function AS_Segment_e5292ce218bd43cea6d2a2baffc16744(eventobject, sectionNumber, rowNumber) {
    return OnClickQualitavive.call(this);
}