function AS_Button_ac222fecb4924328b77ade2021fe7fb0(eventobject, context) {
    return OnclickText.call(this);
}