function AS_Button_364b86ab0aa64adcb78a361d688eef56(eventobject, context) {
    return nofityPriorty_BtnClick.call(this);
}