function AS_TextField_8d926763ec0945e8b4142d5cde844d13(eventobject, changedtext) {
    return onAutoSearch.call(this);
}