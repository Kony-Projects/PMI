function AS_Segment_6a0b123bf12840e49e9c71365e1f9f17(eventobject, sectionNumber, rowNumber) {
    return OnSelectConfigtxt.call(this);
}