function AS_Form_361433e46f024fd98cb97f0b05cbab55(eventobject, neworientation) {
    return onDeviceBack.call(this);
}