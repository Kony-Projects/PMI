function AS_Label_c6393c4c426343578e3894f8b3865a43(eventobject, x, y) {
    return onClickFetchedOrderAll.call(this, eventobject);
}