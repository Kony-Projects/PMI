function AS_Image_b35fa4565314499596081626145d49e4(eventobject, x, y) {
    return SyncBtn_Onclick.call(this);
}