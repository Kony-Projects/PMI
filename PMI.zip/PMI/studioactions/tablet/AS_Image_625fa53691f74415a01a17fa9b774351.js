function AS_Image_625fa53691f74415a01a17fa9b774351(eventobject, x, y) {
    return set_popval.call(this, "PlantSection", popPrevNext, frmLandingScreen.lblPsValue);
}