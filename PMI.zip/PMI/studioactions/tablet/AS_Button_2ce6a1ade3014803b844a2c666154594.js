function AS_Button_2ce6a1ade3014803b844a2c666154594(eventobject) {
    return SyncBtn_Onclick.call(this);
}