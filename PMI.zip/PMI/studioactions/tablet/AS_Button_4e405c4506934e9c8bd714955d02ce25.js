function AS_Button_4e405c4506934e9c8bd714955d02ce25(eventobject, context) {
    return confg_BtnClick.call(this);
}