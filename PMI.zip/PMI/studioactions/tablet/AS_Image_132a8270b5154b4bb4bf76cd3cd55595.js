function AS_Image_132a8270b5154b4bb4bf76cd3cd55595(eventobject, x, y) {
    frmLandingScreen.show();
}