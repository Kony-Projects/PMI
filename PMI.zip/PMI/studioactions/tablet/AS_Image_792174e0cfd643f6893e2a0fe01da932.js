function AS_Image_792174e0cfd643f6893e2a0fe01da932(eventobject, x, y) {
    hbxHeaderPop.lblHeaderName.text = "Delete";
    popDelete.show();
}