function AS_Popup_54528ef909ef43d6bd53c7810d4c9d20(eventobject) {
    hbxHeaderPop.lblHeaderName.text = "Notification";
}