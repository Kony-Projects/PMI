function AS_Button_224b753e96cf4780bb6d2d90f667855c(eventobject) {
    popup_Dismiss.call(this);
    nav_onback_btn_press.call(this);
}