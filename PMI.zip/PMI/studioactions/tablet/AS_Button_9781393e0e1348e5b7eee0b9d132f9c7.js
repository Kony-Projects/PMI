function AS_Button_9781393e0e1348e5b7eee0b9d132f9c7(eventobject) {
    return DeleteBtnonClick.call(this);
}