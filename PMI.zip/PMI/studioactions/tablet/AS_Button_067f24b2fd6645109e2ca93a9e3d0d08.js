function AS_Button_067f24b2fd6645109e2ca93a9e3d0d08(eventobject) {
    return login_identity.call(this);
}