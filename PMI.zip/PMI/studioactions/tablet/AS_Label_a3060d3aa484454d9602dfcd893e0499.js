function AS_Label_a3060d3aa484454d9602dfcd893e0499(eventobject, x, y) {
    return set_popval.call(this, "PmaType", popPrevNext, frmLandingScreen.lblPmTypeVal);
}