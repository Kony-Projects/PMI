function AS_Label_aabfbc53bede4715a2baeee7c4b08d3f(eventobject, x, y) {
    return onClickFetchedOrderAll.call(this, eventobject);
}