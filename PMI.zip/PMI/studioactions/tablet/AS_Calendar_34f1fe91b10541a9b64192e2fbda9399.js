function AS_Calendar_34f1fe91b10541a9b64192e2fbda9399(eventobject, isValidDateSelected) {
    return end_date.call(this);
}