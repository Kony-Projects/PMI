function AS_Segment_48d7795b916e402789fe328b58e0685c(eventobject, sectionNumber, rowNumber) {
    return OnSegRowClickGetOrder.call(this);
}