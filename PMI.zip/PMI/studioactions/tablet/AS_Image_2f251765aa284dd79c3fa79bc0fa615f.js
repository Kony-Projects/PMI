function AS_Image_2f251765aa284dd79c3fa79bc0fa615f(eventobject, x, y) {
    frmHelpScreen.show();
}