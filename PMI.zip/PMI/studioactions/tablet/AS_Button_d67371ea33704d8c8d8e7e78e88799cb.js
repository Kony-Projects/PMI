function AS_Button_d67371ea33704d8c8d8e7e78e88799cb(eventobject) {
    return submitEmailSubject.call(this);
}