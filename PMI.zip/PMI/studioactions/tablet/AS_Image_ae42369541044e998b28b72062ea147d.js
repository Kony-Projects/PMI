function AS_Image_ae42369541044e998b28b72062ea147d(eventobject, x, y) {
    return set_popval.call(this, "Inspection Route", popPrevNext, frmLandingScreen.lblInsValue);
}