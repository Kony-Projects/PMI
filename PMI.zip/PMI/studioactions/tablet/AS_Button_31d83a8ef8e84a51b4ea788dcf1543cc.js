function AS_Button_31d83a8ef8e84a51b4ea788dcf1543cc(eventobject, context) {
    return AS_Button_ed9b1f4945634bdb8469fd38f6b2bb41(eventobject, context);
}

function AS_Button_ed9b1f4945634bdb8469fd38f6b2bb41(eventobject, context) {}