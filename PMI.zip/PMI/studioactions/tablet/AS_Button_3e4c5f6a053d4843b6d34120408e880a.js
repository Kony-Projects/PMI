function AS_Button_3e4c5f6a053d4843b6d34120408e880a(eventobject) {
    return CheckforSameFilters.call(this);
}