function AS_Label_15783a5ddf444cdd911b62ce861aa602(eventobject, x, y) {
    return set_popval.call(this, "PlannerGroup", popPrevNext, frmLandingScreen.lblPgValue);
}