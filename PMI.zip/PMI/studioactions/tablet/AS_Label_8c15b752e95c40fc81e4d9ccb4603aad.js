function AS_Label_8c15b752e95c40fc81e4d9ccb4603aad(eventobject, x, y) {
    frmChangePassword.show();
}