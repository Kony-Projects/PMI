function AS_Button_37b1315c76e4441e9b28ba01970a76be(eventobject) {
    return SyncBtn_OnclickZWI44.call(this);
}