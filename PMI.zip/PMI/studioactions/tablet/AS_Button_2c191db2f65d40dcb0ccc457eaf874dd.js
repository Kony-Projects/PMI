function AS_Button_2c191db2f65d40dcb0ccc457eaf874dd(eventobject) {
    popLongText.dismiss();
}