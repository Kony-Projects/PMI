function AS_Form_e02f4bc567c64ce6a2f9bfff46cb8c44(eventobject) {
    return initSyncSession.call(this);
}