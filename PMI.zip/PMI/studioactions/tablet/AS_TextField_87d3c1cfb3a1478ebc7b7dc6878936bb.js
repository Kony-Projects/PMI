function AS_TextField_87d3c1cfb3a1478ebc7b7dc6878936bb(eventobject, x, y) {
    return onTextBeginQa.call(this);
}