function AS_ListBox_f35627c2344b4fcc893f72ea64d41546(eventobject) {
    return getLabel_Code.call(this);
}