function AS_Label_32a31fc10bf540349d7cb69d643c3c9a(eventobject, x, y) {
    return onClickFetchedOrder.call(this, eventobject);
}