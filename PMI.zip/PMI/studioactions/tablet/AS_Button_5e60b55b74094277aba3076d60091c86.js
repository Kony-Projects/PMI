function AS_Button_5e60b55b74094277aba3076d60091c86(eventobject) {
    return getFetchOrder2.call(this);
}