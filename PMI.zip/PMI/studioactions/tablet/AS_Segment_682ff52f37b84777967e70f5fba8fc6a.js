function AS_Segment_682ff52f37b84777967e70f5fba8fc6a(eventobject, sectionNumber, rowNumber) {
    return OnSegRowClickGetOrder_ziw.call(this);
}