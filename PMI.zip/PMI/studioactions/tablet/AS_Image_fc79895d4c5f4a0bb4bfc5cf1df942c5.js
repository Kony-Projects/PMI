function AS_Image_fc79895d4c5f4a0bb4bfc5cf1df942c5(eventobject, x, y) {
    frmLogin.show();
}