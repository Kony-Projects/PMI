function AS_TextField_6706fa4798d7494498dddb95aef4d916(eventobject, changedtext) {
    return OnTextChange_Textbox.call(this);
}