function AS_Label_720dd58d5e864470ab2fa88ff36da829(eventobject, x, y) {
    frmChangePassword.show();
}