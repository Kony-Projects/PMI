function AS_Button_78df9f4517d34e9f94928ea071b19672(eventobject) {
    return completeYes.call(this);
}