function AS_Label_eac266de8d4c405fbe7098c13a35956d(eventobject, x, y) {
    return call_empty_func.call(this);
}