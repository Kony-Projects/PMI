function AS_Label_2ca797729a324c1dbf898987c55ff6f0(eventobject, x, y) {
    return onClickFetchedOrder.call(this, eventobject);
}