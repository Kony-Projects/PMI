function AS_Button_c2a85e9c9e0d4d1abcb69b10ab399670(eventobject) {
    return tfasites_NextPrev.call(this, "Next");
}