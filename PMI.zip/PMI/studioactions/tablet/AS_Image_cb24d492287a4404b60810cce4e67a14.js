function AS_Image_cb24d492287a4404b60810cce4e67a14(eventobject, x, y) {
    return ClickOnImgofSubOrderList.call(this);
}