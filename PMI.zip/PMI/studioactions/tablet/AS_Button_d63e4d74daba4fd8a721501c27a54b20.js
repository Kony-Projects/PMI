function AS_Button_d63e4d74daba4fd8a721501c27a54b20(eventobject) {
    return syncSuccessOk.call(this);
}