function AS_Popup_f8c06be747f444fa95cb57aef2c67310(eventobject) {
    popNotification.destroy();
}