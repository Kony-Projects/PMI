function AS_Image_e3adcd77317b4e4abea2cf816b0bec3c(eventobject, x, y) {
    return SyncBtn_Onclick.call(this);
}