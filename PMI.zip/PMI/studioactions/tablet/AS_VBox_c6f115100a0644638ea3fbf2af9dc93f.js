function AS_VBox_c6f115100a0644638ea3fbf2af9dc93f(eventobject) {
    popPrevNext.txtSearch.text = "";
    popup_Dismiss.call(this);
}