function AS_VBox_efc1429a443a48aebf5c2f50aa14d28c(eventobject) {
    return tfasites_NextPrev.call(this, "Next");
}