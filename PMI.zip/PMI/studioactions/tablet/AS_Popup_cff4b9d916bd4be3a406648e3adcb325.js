function AS_Popup_cff4b9d916bd4be3a406648e3adcb325(eventobject) {
    hbxHeaderPop.lblHeaderName.text = "Delete";
}