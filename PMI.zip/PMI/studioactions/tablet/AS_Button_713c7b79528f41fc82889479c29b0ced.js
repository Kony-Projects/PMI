function AS_Button_713c7b79528f41fc82889479c29b0ced(eventobject) {
    popup_Dismiss.call(this);
    popLogout.dismiss();
}