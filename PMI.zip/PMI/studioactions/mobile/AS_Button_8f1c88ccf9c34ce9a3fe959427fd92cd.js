function AS_Button_8f1c88ccf9c34ce9a3fe959427fd92cd(eventobject) {
    return LongText_Submit.call(this);
}