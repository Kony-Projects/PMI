function AS_Image_88f21c4c83a14c0bbdf105db3ebd9d38(eventobject, x, y) {
    return nofityPriorty_BtnClick.call(this);
}