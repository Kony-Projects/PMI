function AS_Segment_16358616ca944388a30923fcf0703748(eventobject, sectionNumber, rowNumber) {
    popNotifyPriorty.dismiss();
}