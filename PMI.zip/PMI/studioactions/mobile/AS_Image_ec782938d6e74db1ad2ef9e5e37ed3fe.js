function AS_Image_ec782938d6e74db1ad2ef9e5e37ed3fe(eventobject, x, y) {
    return ClickOnImgofSubOrderList.call(this);
}