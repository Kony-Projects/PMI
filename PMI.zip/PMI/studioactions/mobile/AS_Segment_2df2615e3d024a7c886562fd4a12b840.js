function AS_Segment_2df2615e3d024a7c886562fd4a12b840(eventobject, sectionNumber, rowNumber) {
    return OnSelectNotfytxt.call(this);
}