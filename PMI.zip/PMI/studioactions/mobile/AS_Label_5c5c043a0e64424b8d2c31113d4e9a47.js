function AS_Label_5c5c043a0e64424b8d2c31113d4e9a47(eventobject, x, y) {
    return set_popval.call(this, "PMOrderType", popPrevNext, frmLandingScreen.lblPmOrderVal);
}