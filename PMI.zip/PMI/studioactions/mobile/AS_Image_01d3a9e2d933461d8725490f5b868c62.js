function AS_Image_01d3a9e2d933461d8725490f5b868c62(eventobject, x, y) {
    return SyncBtn_Onclick.call(this);
}