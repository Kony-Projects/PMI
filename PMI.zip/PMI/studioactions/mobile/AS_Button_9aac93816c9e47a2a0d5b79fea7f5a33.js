function AS_Button_9aac93816c9e47a2a0d5b79fea7f5a33(eventobject, context) {
    return Attachment_Btnonclick_ZWI44.call(this);
}