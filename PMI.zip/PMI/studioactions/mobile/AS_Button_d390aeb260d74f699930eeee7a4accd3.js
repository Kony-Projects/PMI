function AS_Button_d390aeb260d74f699930eeee7a4accd3(eventobject) {
    return syncSuccessOk.call(this);
}