function AS_Button_bf6378d4aa0344259b91f258537de7f7(eventobject, context) {
    return OnclickText.call(this);
}