function AS_Camera_ff063a81097a4bf090e63552521b8c48(eventobject) {
    return onCapture.call(this);
}