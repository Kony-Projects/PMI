function AS_Segment_cfb1cf2af04f4986b1643745107c2315(eventobject, sectionNumber, rowNumber) {
    return OnSegRowClickGetOrder_ziw.call(this);
}