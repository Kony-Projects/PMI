function AS_Label_35c293d9d2334830a66d5657f90c7662(eventobject, x, y) {
    return call_empty_func.call(this);
}