function AS_Segment_ac94a2cdff3e4752a34c0fa4426d5394(eventobject, sectionNumber, rowNumber) {
    return onSelectpopTxt.call(this);
}