function AS_Popup_f413b6fba8b846d98013c3e34712174a(eventobject) {
    popNotification.destroy();
}