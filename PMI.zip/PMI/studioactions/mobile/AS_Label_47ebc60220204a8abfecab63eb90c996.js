function AS_Label_47ebc60220204a8abfecab63eb90c996(eventobject, x, y) {
    return onClickFetchedOrderAll.call(this, null);
}