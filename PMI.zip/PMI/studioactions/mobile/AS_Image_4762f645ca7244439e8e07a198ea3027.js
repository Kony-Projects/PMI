function AS_Image_4762f645ca7244439e8e07a198ea3027(eventobject, x, y) {
    return IbuttonClick_i44.call(this);
}