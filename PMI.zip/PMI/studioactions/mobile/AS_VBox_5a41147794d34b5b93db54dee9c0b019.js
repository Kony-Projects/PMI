function AS_VBox_5a41147794d34b5b93db54dee9c0b019(eventobject) {
    return nav_onhome_img_click.call(this);
}