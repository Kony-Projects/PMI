function AS_VBox_f8854e84fbb740adad759d408ec0ea0f(eventobject) {
    return nav_onback_btn_press.call(this);
}