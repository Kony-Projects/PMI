function AS_Button_ef71d83ec1da4dabb37d5df9102e03ef(eventobject) {
    frmHelpScreen.show();
}