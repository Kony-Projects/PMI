function AS_Image_f04ef17869684f05840bdcbdbf7016dd(eventobject, x, y) {
    return set_popval.call(this, "PlannerGroup", popPrevNext, frmLandingScreen.lblPgValue);
}