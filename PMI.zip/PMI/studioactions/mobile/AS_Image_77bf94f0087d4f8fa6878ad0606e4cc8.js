function AS_Image_77bf94f0087d4f8fa6878ad0606e4cc8(eventobject, x, y) {
    return set_popval.call(this, "PMOrderType", popPrevNext, frmLandingScreen.lblPmOrderVal);
}