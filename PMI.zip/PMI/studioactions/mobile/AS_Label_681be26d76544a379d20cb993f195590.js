function AS_Label_681be26d76544a379d20cb993f195590(eventobject, x, y) {
    return call_empty_func.call(this);
}