function AS_Label_2cbcf874e0764d0d86393d82ead218e0(eventobject, x, y) {
    return onClickFetchedOrder.call(this, eventobject);
}