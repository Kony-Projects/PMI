function AS_Image_a3cd27c8d7a046cbbdc9fda5b35d1cfe(eventobject, x, y) {
    return ClickOnImgOrderList.call(this);
}