function AS_Label_b983fc8fbb0b4ad6ab8860a6f508ed22(eventobject, x, y) {
    return call_empty_func.call(this);
}