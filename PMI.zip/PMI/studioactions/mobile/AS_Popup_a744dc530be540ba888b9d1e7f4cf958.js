function AS_Popup_a744dc530be540ba888b9d1e7f4cf958(eventobject) {
    popCreateTicket.destroy();
}