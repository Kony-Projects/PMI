function AS_Label_90ba82736ddf4401b8d603409b289b84(eventobject, x, y) {
    return onClickFetchedOrderAll.call(this, null);
}