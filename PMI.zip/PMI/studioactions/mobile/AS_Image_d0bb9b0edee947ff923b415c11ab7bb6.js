function AS_Image_d0bb9b0edee947ff923b415c11ab7bb6(eventobject, x, y) {
    return set_popval.call(this, "Inspection Route", popPrevNext, frmLandingScreen.lblInsValue);
}