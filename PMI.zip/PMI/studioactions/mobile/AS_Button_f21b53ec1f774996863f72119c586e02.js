function AS_Button_f21b53ec1f774996863f72119c586e02(eventobject, context) {
    return Attachment_Btnonclick.call(this);
}