function AS_Form_ec2c1cd3d0054d2e8eda04ee769e85ef(eventobject) {
    return onDeviceBack.call(this);
}