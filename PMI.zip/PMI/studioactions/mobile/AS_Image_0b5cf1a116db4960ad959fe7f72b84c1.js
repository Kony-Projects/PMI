function AS_Image_0b5cf1a116db4960ad959fe7f72b84c1(eventobject, x, y) {
    return ClickOnImgOrderList_ziw44.call(this);
}