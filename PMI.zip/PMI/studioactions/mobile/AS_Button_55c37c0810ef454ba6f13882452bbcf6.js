function AS_Button_55c37c0810ef454ba6f13882452bbcf6(eventobject) {
    return popCancel.call(this, "logout");
}