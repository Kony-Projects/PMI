function AS_Button_526ff7013034476aadfc6b5bac5aa855(eventobject) {
    return popup_Dismiss.call(this);
}