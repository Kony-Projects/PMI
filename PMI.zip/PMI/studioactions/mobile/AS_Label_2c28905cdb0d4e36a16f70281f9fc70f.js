function AS_Label_2c28905cdb0d4e36a16f70281f9fc70f(eventobject, x, y) {
    return set_popval.call(this, "PlantSection", popPrevNext, frmLandingScreen.lblPsValue);
}