function AS_Button_66bdd9c17d124f8d9e19367a2f4009a2(eventobject) {
    return CheckforSameFilters.call(this);
}