function AS_Form_be44691b4efb4dd98fe58f34d060c9f3(eventobject) {
    hbxHeaderPop.lblHeaderName.text = "Exit";
    popBack.lblBack.text = "Do You Want to Exit ?";
    popBack.show()
}