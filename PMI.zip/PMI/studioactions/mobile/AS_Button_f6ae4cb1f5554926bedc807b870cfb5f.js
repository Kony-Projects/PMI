function AS_Button_f6ae4cb1f5554926bedc807b870cfb5f(eventobject) {
    hbxHeaderPop.lblHeaderName.text = "Logout";
    popLogout.show()
}