function AS_Button_a462558450df4e12b33415b5e53b6280(eventobject) {
    popup_Dismiss.call(this);
    popLogout.dismiss();
}