function AS_Image_e67a7aa76f88413d9ec9596eb54f3072(eventobject, x, y) {
    return SyncBtn_OnclickZWI44.call(this);
}