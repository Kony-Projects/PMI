function AS_Button_a140e596af9b4bca9bb64800be27d440(eventobject) {
    popup_Dismiss.call(this);
    nav_onback_btn_press.call(this);
}