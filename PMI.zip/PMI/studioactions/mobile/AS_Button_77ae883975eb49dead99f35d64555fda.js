function AS_Button_77ae883975eb49dead99f35d64555fda(eventobject) {
    frmLandingScreen.show();
}