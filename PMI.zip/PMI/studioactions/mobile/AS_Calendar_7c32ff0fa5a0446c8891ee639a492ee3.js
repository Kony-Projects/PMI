function AS_Calendar_7c32ff0fa5a0446c8891ee639a492ee3(eventobject, isValidDateSelected) {
    return six_day_check.call(this);
}