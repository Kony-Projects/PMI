function AS_Image_5138ea7cc0ea4474aeb2ea01308e667c(eventobject, x, y) {
    return confg_BtnClick.call(this);
}