function AS_Button_1230fc4cd01c4b60950c02d651b9a195(eventobject) {
    return CreateBtnClick.call(this);
}