function AS_Label_f19423c2f6bd4e52875575d634ac9f4b(eventobject, x, y) {
    return set_popval.call(this, "PlannerGroup", popPrevNext, frmLandingScreen.lblPgValue);
}