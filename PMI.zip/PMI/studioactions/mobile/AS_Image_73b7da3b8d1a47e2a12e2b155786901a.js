function AS_Image_73b7da3b8d1a47e2a12e2b155786901a(eventobject, x, y) {
    return set_popval.call(this, "PmaType", popPrevNext, frmLandingScreen.lblPmTypeVal);
}