function AS_Image_b6592e2a52cf473198f4e51a987c6789(eventobject, x, y) {
    return set_popval.call(this, "PlantSection", popPrevNext, frmLandingScreen.lblPsValue);
}