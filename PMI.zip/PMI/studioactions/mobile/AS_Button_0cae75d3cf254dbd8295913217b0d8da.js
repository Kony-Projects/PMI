function AS_Button_0cae75d3cf254dbd8295913217b0d8da(eventobject) {
    return tfasites_NextPrev.call(this, null);
}