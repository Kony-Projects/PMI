function AS_Button_dd5856d4c4ba441984bf3ba4107f31a4(eventobject) {
    return SyncBtn_Onclick.call(this);
}