function AS_Segment_9fc9d768ae5c46f8a61a1ffe84c5ef67(eventobject, sectionNumber, rowNumber) {
    return OnSelectConfigtxt.call(this);
}