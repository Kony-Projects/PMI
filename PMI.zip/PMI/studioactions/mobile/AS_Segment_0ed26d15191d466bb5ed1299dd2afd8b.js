function AS_Segment_0ed26d15191d466bb5ed1299dd2afd8b(eventobject, sectionNumber, rowNumber) {
    return rowSegCLick.call(this, null);
}