function AS_Image_f0b7fb8a99f5406a9282a064c623e3e5(eventobject, x, y) {
    hbxHeaderPop.lblHeaderName.text = "Delete";
    popDelete.show();
    delflag = true;
}