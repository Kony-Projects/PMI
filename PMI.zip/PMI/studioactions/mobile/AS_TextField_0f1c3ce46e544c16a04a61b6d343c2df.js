function AS_TextField_0f1c3ce46e544c16a04a61b6d343c2df(eventobject, changedtext) {
    return OnTextChange_Textbox.call(this);
}