function AS_Image_62e37ccd8fbc45c38839ef7872764c77(eventobject, x, y) {
    return nav_onclick_imghelpbtn.call(this);
}