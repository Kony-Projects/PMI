function AS_Button_ab0706b9d7db43ada379799273be6970(eventobject) {
    return getFetchOrder2.call(this);
}