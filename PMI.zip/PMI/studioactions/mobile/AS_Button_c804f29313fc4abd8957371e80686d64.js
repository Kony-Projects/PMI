function AS_Button_c804f29313fc4abd8957371e80686d64(eventobject, context) {
    return confg_BtnClick.call(this);
}