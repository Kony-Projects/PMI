function AS_Popup_c59878995b0b4a76aa9847bf3d332467(eventobject) {
    hbxHeaderPop.lblHeaderName.text = "Delete";
}