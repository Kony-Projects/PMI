function AS_Image_f90fe4bd9952423daa85170e74e055f2(eventobject, x, y) {
    return ClickOnImgofSubOrderListZI44.call(this);
}