function AS_Form_47f90f7759334f2a8e3e4d671fe5fce7(eventobject) {
    return onDeviceBack.call(this);
}