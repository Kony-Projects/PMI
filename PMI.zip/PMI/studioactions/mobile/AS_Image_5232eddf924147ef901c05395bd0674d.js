function AS_Image_5232eddf924147ef901c05395bd0674d(eventobject, x, y) {
    return back_NavigateOrder.call(this);
}