function AS_Button_e65dc366fd3a405ba3b6c9e4c94bee95(eventobject, context) {
    return long_BtnClick.call(this);
}