function AS_Label_88d96b27413b4e0395b7e3039260ffbb(eventobject, x, y) {
    return onClickFetchedOrder.call(this, eventobject);
}