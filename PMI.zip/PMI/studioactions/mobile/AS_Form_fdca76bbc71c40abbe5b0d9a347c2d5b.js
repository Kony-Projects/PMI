function AS_Form_fdca76bbc71c40abbe5b0d9a347c2d5b(eventobject, neworientation) {
    return onDeviceBack.call(this);
}