function AS_TextField_f20edc5e68ad42788df19a114c4a1a73(eventobject, changedtext) {
    return onAutoSearch.call(this);
}