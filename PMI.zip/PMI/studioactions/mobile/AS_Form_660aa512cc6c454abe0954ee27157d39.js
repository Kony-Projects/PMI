function AS_Form_660aa512cc6c454abe0954ee27157d39(eventobject) {
    return initSyncSession.call(this);
}