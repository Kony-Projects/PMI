function AS_Image_ff8c94a18a6b4db592ae794f9c291ee2(eventobject, x, y) {
    return ibuttonClick_ZQE.call(this);
}